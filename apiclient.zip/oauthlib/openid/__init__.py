# -*- coding: utf-8 -*-
"""
oauthlib.openid
~~~~~~~~~~~~~~

"""
from __future__ import absolute_import, unicode_literals

from .connect.core.endpoints import Server
from .connect.core.endpoints import UserInfoEndpoint
from .connect.core.request_validator import RequestValidator
